<?php
trait Poeticsoft_Partner_Trait_Jitsi {  

  public function register_jitsi() {

  }
}
