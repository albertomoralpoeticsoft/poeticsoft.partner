<?php

require_once __DIR__ . '/traits/trait-api.php';
require_once __DIR__ . '/traits/trait-ui.php';
require_once __DIR__ . '/traits/trait-campaign.php';
require_once __DIR__ . '/traits/trait-campaign-list.php';
require_once __DIR__ . '/traits/trait-campaign-media.php';
require_once __DIR__ . '/traits/trait-publish.php';
require_once __DIR__ . '/traits/trait-block.php';
require_once __DIR__ . '/traits/trait-jitsi.php';
require_once __DIR__ . '/traits/trait-jitsi-ui.php';
require_once __DIR__ . '/traits/trait-jitsi-generalfields.php';
require_once __DIR__ . '/traits/trait-jitsi-api.php';
require_once __DIR__ . '/traits/trait-jitsi-shortcode.php';

class Poeticsoft_Partner {

  use Poeticsoft_Partner_Trait_API;
  use Poeticsoft_Partner_Trait_UI;
  use Poeticsoft_Partner_Trait_Campaign;
  use Poeticsoft_Partner_Trait_Campaign_List;
  use Poeticsoft_Partner_Trait_Campaign_Media;
  use Poeticsoft_Partner_Trait_Publish;
  use Poeticsoft_Partner_Trait_Block;
  use Poeticsoft_Partner_Trait_Jitsi;
  use Poeticsoft_Partner_Trait_Jitsi_API;
  use Poeticsoft_Partner_Trait_Jitsi_UI;
  use Poeticsoft_Partner_Trait_Jitsi_Generalfields;
  use Poeticsoft_Partner_Trait_Jitsi_Shortcode;

  private static $instance = null;
  public static $dir;
  public static $url;

  public static function get_instance() {

    if (self::$instance === null) {

      self::$instance = new self();
    }

    return self::$instance;
  }

  private function __construct() {

    $this->set_vars();    

    /* Conditional load of tools */

    $this->register_ui();
    $this->register_api();
    $this->register_campaign();
    $this->register_campaign_list();
    $this->register_campaign_media();
    $this->register_publish();
    $this->register_block();
    $this->register_jitsi();
    $this->register_jitsi_api();
    $this->register_jitsi_ui();
    $this->register_jitsi_generalfields();
    $this->register_jitsi_shortcode();
  }

  private function set_vars() {

    self::$dir = plugin_dir_path(dirname(__FILE__));
    self::$url = plugin_dir_url(dirname(__FILE__));
  }

  public function log($display, $withdate = false) { 

    $text = is_string($display) ? 
    $display 
    : 
    json_encode($display, JSON_PRETTY_PRINT);

    $message = $withdate ? 
    date("d-m-y h:i:s") . PHP_EOL
    :
    '';

    $message .= $text . PHP_EOL;

    file_put_contents(
      self::$dir . '/log.txt',
      $message,
      FILE_APPEND
    );
  }

  public function slugify($text) {
  
    $text = strtolower($text);
    $text = preg_replace('~[^\\pL\\d]+~u', '-', $text);
    $text = iconv('utf-8', 'us-ascii//TRANSLIT//IGNORE', $text);
    $text = preg_replace('~-+~', '-', $text);
    if (empty($text)) {
        
      return 'n-a';
    }
    
    return $text;
  }
}
